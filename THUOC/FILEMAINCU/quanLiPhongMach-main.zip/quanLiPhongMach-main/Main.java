public class Main {
    public static void main(String args[]) {
        QUANLIDSTHUOC trinhQuanLi = new QUANLIDSTHUOC();
        
        trinhQuanLi.menu();
    }
}


// thấy gì ko mấy ôg

// tôi không thấy cái cmt trên đâu 