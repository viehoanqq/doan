/**
 * arrayInterface
 */
public interface arrayInterfaceTHUOC {
    public void themThuoc(THUOC newTHUOC);
    public void xoaThuoc(int index);
    public void suaThongTin();
    public void inDanhSachThuoc();
    public void nhapThuoc(int soThuocCanNhap);
    public void timThuocTheoTen(String tenThuocCanTim);
    public THUOC timThuocTheoMa(String maThuocCantTim);
}


